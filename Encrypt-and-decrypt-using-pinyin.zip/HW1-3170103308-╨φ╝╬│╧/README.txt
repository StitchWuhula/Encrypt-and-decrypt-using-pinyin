There are 3 files in the folder.
Encrypt_and_Decrypt.c requires a basic C compiler.
Run Encrypt_and_Decrypt.exe, inputing "E" stands for Encryption while "D" for  Decryption.
See details in Report.pdf